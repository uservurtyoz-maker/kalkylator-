package com.example.calcai

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Base64
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.UUID

class MainActivity : Activity() {

    companion object {
        const val REQ_CAM = 1
        const val REQ_PERM = 2
        const val REQ_PICK = 3
        const val MODEL_VISION = "qwen/qwen3.8-27b"     // reads the photo
        const val MODEL_SOLVE = "openai/gpt-oss-120b"   // solves the transcribed task
        val NUS_RX: UUID = UUID.fromString("6E400002-B5A3-F393-E0A9-E50E24DCCA9E")

        const val READ_PROMPT =
            "Если фото перевёрнуто, мысленно переверни его. Перепиши полностью условие задания с фото, включая номера заданий как в учебнике вместе со всеми вариантами ответа, без решения. Если есть рисунок или чертёж, " +
            "опиши его: фигуры, все числа, буквы и подписи. Если на фото только арифметический пример, " +
            "ответь только им одной строкой, например: 7*7+2*2."

        const val SOLVE_PROMPT =
            "Реши задачу по условию ниже. Ответь по-русски. Первая строка: итоговый ответ коротко, " +
            "например: x = 5 или S = 12 см². Далее краткое решение в 2-4 строках. " +
            "Если данных не хватает, так и напиши.\n\nУсловие:\n"
        const val SHORT_RULE =
            "Ответь на задание ниже. Если это тест с вариантами, проверь каждый вариант и выведи только текст " +
            "правильного варианта, как он записан в условии, без остальных вариантов. Если это задача, выведи только " +
            "итоговые ответы, каждый в отдельной строке. Без решения и пояснений.\n\nЗадание:\n"

        const val JSON_RULE =
            "Реши задания ниже. Верни ТОЛЬКО JSON, без пояснений и без markdown: " +
            "{\"items\":[{\"num\":\"473\",\"id\":\"a\",\"expr\":\"условие\",\"answer\":\"итоговый ответ\"," +
            "\"solution\":\"краткое решение в 2-4 строках\"}]}. " +
            "num - номер задания из учебника. id - буква подпункта; для каждого номера буквы начинаются с a заново. " +
            "Один объект на каждую букву, без дублей, ни один подпункт не пропускай. " +
            "Математику пиши без LaTeX: корень как √(...), степень как x^2, дробь как (a)/(b). " +
            "Текст пиши по-русски.\n\nЗадания:\n"

        const val PLAIN =
            " Пиши обычным текстом: без LaTeX, без знаков $ и без звёздочек. " +
            "Дроби пиши как (a)/(b), умножение как *, степень как ^."
    }

    private lateinit var prefs: SharedPreferences
    private lateinit var status: TextView
    private lateinit var keyInput: EditText
    private val ui = Handler(Looper.getMainLooper())
    private var gatt: BluetoothGatt? = null
    private var rxChar: BluetoothGattCharacteristic? = null
    private var photoFile: File? = null

    override fun onCreate(savedState: Bundle?) {
        super.onCreate(savedState)
        prefs = getSharedPreferences("cfg", MODE_PRIVATE)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 40, 40, 40)
        }
        keyInput = EditText(this).apply {
            hint = "Groq API key"
            setText(prefs.getString("key", ""))
        }
        val saveBtn = Button(this).apply {
            text = "Save key"
            setOnClickListener {
                prefs.edit().putString("key", keyInput.text.toString().trim()).apply()
                toast("Saved")
            }
        }
        val connBtn = Button(this).apply {
            text = "Connect CalcAI"
            setOnClickListener { connect() }
        }
        val photoBtn = Button(this).apply {
            text = "Photo -> Groq -> screen"
            setOnClickListener { takePhoto() }
        }
        val pickBtn = Button(this).apply {
            text = "Pick photo from gallery"
            setOnClickListener { pickFromGallery() }
        }
        status = TextView(this).apply {
            text = "Not connected"
            setTextIsSelectable(true)
        }
        val scroll = ScrollView(this).apply { addView(status) }

        root.addView(keyInput)
        root.addView(saveBtn)
        root.addView(connBtn)
        root.addView(photoBtn)
        root.addView(pickBtn)
        root.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        requestNeededPermissions()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun requestNeededPermissions() {
        val list = mutableListOf(Manifest.permission.CAMERA, Manifest.permission.ACCESS_FINE_LOCATION)
        if (Build.VERSION.SDK_INT >= 31) {
            list += Manifest.permission.BLUETOOTH_SCAN
            list += Manifest.permission.BLUETOOTH_CONNECT
        }
        val missing = list.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), REQ_PERM)
    }

    // ---------- Bluetooth ----------

    @SuppressLint("MissingPermission")
    private fun connect() {
        val adapter = (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter
        if (adapter == null || !adapter.isEnabled) {
            toast("Turn Bluetooth on")
            return
        }
        gatt?.close()
        gatt = null
        rxChar = null
        val scanner = adapter.bluetoothLeScanner
        status.text = "Scanning..."
        val cb = object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult) {
                val name = result.device.name ?: result.scanRecord?.deviceName
                if (name == "CalcAI") {
                    scanner.stopScan(this)
                    status.text = "Found CalcAI, connecting..."
                    gatt = result.device.connectGatt(
                        this@MainActivity, false, gattCb, BluetoothDevice.TRANSPORT_LE
                    )
                }
            }
        }
        scanner.startScan(cb)
        ui.postDelayed({
            scanner.stopScan(cb)
            if (gatt == null) status.text = "CalcAI not found. Close other BLE apps and turn Location on."
        }, 15000)
    }

    private val gattCb = object : BluetoothGattCallback() {
        @SuppressLint("MissingPermission")
        override fun onConnectionStateChange(g: BluetoothGatt, st: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                g.discoverServices()
            } else {
                rxChar = null
                g.close()
                gatt = null
                ui.post { status.text = "Disconnected. Press Connect CalcAI again." }
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, st: Int) {
            rxChar = g.services.flatMap { it.characteristics }.firstOrNull { it.uuid == NUS_RX }
            ui.post {
                status.text = if (rxChar != null) "Connected to CalcAI" else "RX characteristic not found"
            }
        }
    }

    // Sends UTF-8 text in 20-byte pieces; the board shows it after a newline
    @SuppressLint("MissingPermission")
    private fun sendToBoard(text: String) {
        val g = gatt
        val ch = rxChar
        if (g == null || ch == null) {
            ui.post { status.text = "Not connected to CalcAI (board not shown)" }
            return
        }
        Thread {
            val bytes = (text.replace("\n", " ") + "\n").toByteArray(Charsets.UTF_8)
            ch.writeType = BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
            var i = 0
            while (i < bytes.size) {
                val end = minOf(i + 20, bytes.size)
                ch.value = bytes.copyOfRange(i, end)
                g.writeCharacteristic(ch)
                i = end
                Thread.sleep(40)
            }
        }.start()
    }

    // ---------- Photo input ----------

    private fun takePhoto() {
        val dir = File(cacheDir, "photos").apply { mkdirs() }
        val f = File(dir, "task.jpg")
        photoFile = f
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            .putExtra(MediaStore.EXTRA_OUTPUT, uri)
            .addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        startActivityForResult(intent, REQ_CAM)
    }

    private fun pickFromGallery() {
        val intent = Intent(Intent.ACTION_GET_CONTENT).setType("image/*")
        startActivityForResult(intent, REQ_PICK)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        when (requestCode) {
            REQ_CAM -> photoFile?.let { processImage(it.readBytes()) }
            REQ_PICK -> data?.data?.let { uri ->
                contentResolver.openInputStream(uri)?.use { processImage(it.readBytes()) }
            }
        }
    }

    // Step 1: vision model reads the photo. Step 2: arithmetic is computed on the phone,
    // everything else is solved by a reasoning model from the transcription.
    // Parses the model JSON; returns null if it is broken or cut off
    private fun tryParse(raw: String): JSONObject? {
        return try {
            val start = raw.indexOf('{')
            val end = raw.lastIndexOf('}')
            if (start < 0 || end <= start) return null
            val arr = JSONObject(raw.substring(start, end + 1)).getJSONArray("items")
            val counter = HashMap<String, Int>()
            val items = JSONArray()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val num = o.optString("num", "").trim()
                val k = counter.getOrDefault(num, 0)
                counter[num] = k + 1
                items.put(JSONObject()
                    .put("num", num)
                    .put("id", ('a' + k).toString())
                    .put("expr", cleanMath(o.optString("expr", "")))
                    .put("answer", cleanMath(o.optString("answer", "")))
                    .put("solution", cleanMath(o.optString("solution", ""))))
            }
            if (items.length() > 0) JSONObject().put("items", items) else null
        } catch (e: Exception) {
            null
        }
    }

    // Text for the phone screen: task number, letter and answer
    private fun itemsText(json: JSONObject): String {
        val arr = json.getJSONArray("items")
        val sb = StringBuilder()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            sb.append(o.optString("num")).append(o.optString("id")).append(") ")
                .append(o.optString("answer")).append("\n")
        }
        return sb.toString().trim()
    }

    private fun processImage(jpeg: ByteArray) {
        ui.post { status.text = "Reading photo..." }
        Thread {
            try {
                val transcript = cleanMath(readPhoto(jpeg))
                val compact = transcript.replace(" ", "")
                val json = if (isArithmetic(compact)) {
                    val r = fmt(ExprParser(compact).parse())
                    JSONObject().put("items", JSONArray().put(JSONObject()
                        .put("num", "").put("id", "a").put("expr", transcript)
                        .put("answer", r).put("solution", "")))
                } else {
                    ui.post { status.text = "Solving..." }
                    tryParse(callGroq(MODEL_SOLVE, userMsg(JSON_RULE + transcript), 8000))
                        ?: tryParse(callGroq(MODEL_SOLVE, userMsg(JSON_RULE + transcript), 8000))
                        ?: throw IllegalStateException("модель вернула непонятный ответ, попробуй ещё раз")
                }
                ui.post { status.text = itemsText(json) }
                sendToBoard(json.toString())
            } catch (e: Exception) {
                ui.post { status.text = "Error: ${e.message}" }
            }
        }.start()
    }

    // Converts leftover LaTeX into plain text: \frac{a}{b} -> (a)/(b), \cdot -> *
    private fun cleanMath(text: String): String {
        var s = text
            .replace("\\(", "").replace("\\)", "").replace("\\[", "").replace("\\]", "")
            .replace("\$", "").replace("**", "").replace("\\displaystyle", "")
            .replace("\\cdot", "*").replace("\\times", "*")
            .replace("\\left", "").replace("\\right", "")
            .replace("\\neq", "!=").replace("\\pm", "+-").replace("\\geq", ">=").replace("\\leq", "<=")
            .replace("\\;", "").replace("\\,", "").replace("\\!", "").replace("\\sqrt", "sqrt")
            .replace("²", "^2").replace("³", "^3").replace("•", "*").replace("÷", "/").replace("–", "-")
        val frac = Regex("\\\\frac\\{([^{}]*)\\}\\{([^{}]*)\\}")
        while (frac.containsMatchIn(s)) {
            s = frac.replace(s) { "(${it.groupValues[1]})/(${it.groupValues[2]})" }
        }
        s = s.replace("\\", "")
        return s.trim()
    }

    private fun boardAnswer(s: String): String =
        s.lines().map { it.trim() }.filter { it.isNotEmpty() }.take(4).joinToString("; ")

    private fun isArithmetic(s: String): Boolean =
        s.isNotEmpty() && Regex("[0-9+\\-*/().]+").matches(s) && s.any { it.isDigit() }

    private fun firstLine(s: String): String =
        s.lines().map { it.trim() }.firstOrNull { it.isNotEmpty() }?.take(80) ?: s.take(80)

    private fun fmt(v: Double): String =
        if (v == Math.floor(v) && Math.abs(v) < 1e15) v.toLong().toString()
        else String.format(Locale.US, "%.6f", v).trimEnd('0').trimEnd('.')

    // ---------- Groq ----------

    private fun readPhoto(jpeg: ByteArray): String {
        val b64 = Base64.encodeToString(jpeg, Base64.NO_WRAP)
        val content = JSONArray()
            .put(JSONObject().put("type", "text").put("text", READ_PROMPT + PLAIN))
            .put(JSONObject()
                .put("type", "image_url")
                .put("image_url", JSONObject().put("url", "data:image/jpeg;base64,$b64")))
        return callGroq(MODEL_VISION, userMsg(content), 800)
    }

    private fun solveText(task: String): String =
        callGroq(MODEL_SOLVE, userMsg(SHORT_RULE + task + PLAIN), 3000)

    private fun userMsg(content: Any): JSONArray =
        JSONArray().put(JSONObject().put("role", "user").put("content", content))

    private fun callGroq(model: String, messages: JSONArray, maxTokens: Int): String {
        val key = prefs.getString("key", "") ?: ""
        if (key.isEmpty()) throw IllegalStateException("no API key saved")

        val body = JSONObject()
            .put("model", model)
            .put("max_tokens", maxTokens)
            .put("messages", messages)
            .put("temperature", 0)
            .toString()

        val conn = URL("https://api.groq.com/openai/v1/chat/completions").openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.setRequestProperty("Authorization", "Bearer $key")
        conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
        conn.doOutput = true
        conn.connectTimeout = 20000
        conn.readTimeout = 120000
        conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }

        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream.bufferedReader(Charsets.UTF_8).readText()
        if (code !in 200..299) throw IllegalStateException("HTTP $code: ${text.take(200)}")

        val content = JSONObject(text).getJSONArray("choices").getJSONObject(0)
            .getJSONObject("message").optString("content", "").trim()
        if (content.isEmpty()) throw IllegalStateException("empty answer from $model")
        return content
    }
}

// Recursive-descent parser: + - * / parentheses, unary minus, decimals
class ExprParser(private val s: String) {
    private var pos = 0

    fun parse(): Double {
        val v = expr()
        if (pos != s.length) throw IllegalArgumentException("unexpected char at $pos")
        return v
    }

    private fun expr(): Double {
        var v = term()
        while (pos < s.length && (s[pos] == '+' || s[pos] == '-')) {
            val op = s[pos++]
            val r = term()
            v = if (op == '+') v + r else v - r
        }
        return v
    }

    private fun term(): Double {
        var v = factor()
        while (pos < s.length && (s[pos] == '*' || s[pos] == '/')) {
            val op = s[pos++]
            val r = factor()
            v = if (op == '*') v * r else {
                if (r == 0.0) throw ArithmeticException("division by zero")
                v / r
            }
        }
        return v
    }

    private fun factor(): Double {
        if (pos < s.length && s[pos] == '-') {
            pos++
            return -factor()
        }
        if (pos < s.length && s[pos] == '(') {
            pos++
            val v = expr()
            if (pos >= s.length || s[pos] != ')') throw IllegalArgumentException("missing )")
            pos++
            return v
        }
        val start = pos
        while (pos < s.length && (s[pos].isDigit() || s[pos] == '.')) pos++
        if (start == pos) throw IllegalArgumentException("number expected at $pos")
        return s.substring(start, pos).toDouble()
    }
}

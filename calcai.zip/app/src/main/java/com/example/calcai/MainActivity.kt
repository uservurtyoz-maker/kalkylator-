package com.example.calcai

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Base64
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

class MainActivity : Activity() {

    companion object {
        const val REQ_CAM = 1
        const val REQ_PERM = 2
        const val MODEL = "qwen/qwen3.8-27b"
        val NUS_RX: UUID = UUID.fromString("6E400002-B5A3-F393-E0A9-E50E24DCCA9E")

        // Cyrillic -> Latin, so the monochrome OLED font can show Russian answers
        val TR: Map<Char, String> = mapOf(
            'а' to "a", 'б' to "b", 'в' to "v", 'г' to "g", 'д' to "d", 'е' to "e",
            'ё' to "yo", 'ж' to "zh", 'з' to "z", 'и' to "i", 'й' to "y", 'к' to "k",
            'л' to "l", 'м' to "m", 'н' to "n", 'о' to "o", 'п' to "p", 'р' to "r",
            'с' to "s", 'т' to "t", 'у' to "u", 'ф' to "f", 'х' to "h", 'ц' to "ts",
            'ч' to "ch", 'ш' to "sh", 'щ' to "sch", 'ъ' to "", 'ы' to "y", 'ь' to "",
            'э' to "e", 'ю' to "yu", 'я' to "ya"
        )
    }

    private lateinit var prefs: SharedPreferences
    private lateinit var status: TextView
    private lateinit var keyInput: EditText
    private val ui = Handler(Looper.getMainLooper())
    private var gatt: BluetoothGatt? = null
    private var rxChar: BluetoothGattCharacteristic? = null
    private var photoFile: File? = null

    override fun onCreate(savedState: Bundle?) {
        super.onCreate(savedState)
        prefs = getSharedPreferences("cfg", MODE_PRIVATE)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 40, 40, 40)
        }
        keyInput = EditText(this).apply {
            hint = "Groq API key"
            setText(prefs.getString("key", ""))
        }
        val saveBtn = Button(this).apply {
            text = "Save key"
            setOnClickListener {
                prefs.edit().putString("key", keyInput.text.toString().trim()).apply()
                toast("Saved")
            }
        }
        val connBtn = Button(this).apply {
            text = "Connect CalcAI"
            setOnClickListener { connect() }
        }
        val photoBtn = Button(this).apply {
            text = "Photo -> Groq -> screen"
            setOnClickListener { takePhoto() }
        }
        status = TextView(this).apply {
            text = "Not connected"
            setTextIsSelectable(true)
        }

        val scroll = android.widget.ScrollView(this).apply { addView(status) }
        root.addView(keyInput)
        root.addView(saveBtn)
        root.addView(connBtn)
        root.addView(photoBtn)
        root.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        requestNeededPermissions()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun requestNeededPermissions() {
        val list = mutableListOf(Manifest.permission.CAMERA)
        if (Build.VERSION.SDK_INT >= 31) {
            list += Manifest.permission.BLUETOOTH_SCAN
            list += Manifest.permission.BLUETOOTH_CONNECT
        } else {
            list += Manifest.permission.ACCESS_FINE_LOCATION
        }
        val missing = list.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), REQ_PERM)
    }

    // ---------- Bluetooth ----------

    @SuppressLint("MissingPermission")
    private fun connect() {
        val adapter = (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter
        if (adapter == null || !adapter.isEnabled) {
            toast("Turn Bluetooth on")
            return
        }
        val scanner = adapter.bluetoothLeScanner
        status.text = "Scanning..."
        val cb = object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult) {
                val name = result.device.name ?: result.scanRecord?.deviceName
                if (name == "CalcAI") {
                    scanner.stopScan(this)
                    status.text = "Found CalcAI, connecting..."
                    gatt = result.device.connectGatt(this@MainActivity, false, gattCb)
                }
            }
        }
        scanner.startScan(cb)
        ui.postDelayed({ scanner.stopScan(cb) }, 15000)
    }

    private val gattCb = object : BluetoothGattCallback() {
        @SuppressLint("MissingPermission")
        override fun onConnectionStateChange(g: BluetoothGatt, st: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                g.discoverServices()
            } else {
                rxChar = null
                ui.post { status.text = "Disconnected" }
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, st: Int) {
            rxChar = g.services.flatMap { it.characteristics }.firstOrNull { it.uuid == NUS_RX }
            ui.post {
                status.text = if (rxChar != null) "Connected to CalcAI" else "RX characteristic not found"
            }
        }
    }

    // Sends text in 20-byte pieces; the board shows the text only after a newline
    @SuppressLint("MissingPermission")
    private fun sendToBoard(text: String) {
        val g = gatt
        val ch = rxChar
        if (g == null || ch == null) {
            ui.post { status.text = "Not connected to CalcAI" }
            return
        }
        Thread {
            val bytes = (text.replace("\n", " ") + "\n").toByteArray(Charsets.UTF_8)
            ch.writeType = BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
            var i = 0
            while (i < bytes.size) {
                val end = minOf(i + 20, bytes.size)
                ch.value = bytes.copyOfRange(i, end)
                g.writeCharacteristic(ch)
                i = end
                Thread.sleep(40)
            }
        }.start()
    }

    // Russian text -> Latin letters for the OLED (its font has no Cyrillic)
    private fun toBoardText(s: String): String = buildString {
        for (ch in s) {
            val lower = ch.lowercaseChar()
            val m = TR[lower]
            if (m != null) {
                append(if (ch.isUpperCase()) m.replaceFirstChar { it.uppercaseChar() } else m)
            } else {
                append(ch)
            }
        }
    }

    // ---------- Camera ----------

    private fun takePhoto() {
        val dir = File(cacheDir, "photos").apply { mkdirs() }
        val f = File(dir, "task.jpg")
        photoFile = f
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            .putExtra(MediaStore.EXTRA_OUTPUT, uri)
            .addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        startActivityForResult(intent, REQ_CAM)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_CAM && resultCode == RESULT_OK) {
            val f = photoFile ?: return
            status.text = "Asking Groq..."
            Thread {
                val answer = try {
                    askGroq(f.readBytes())
                } catch (e: Exception) {
                    "Error: ${e.message}"
                }
                ui.post { status.text = "Answer: $answer" }
                sendToBoard(toBoardText(answer))
            }.start()
        }
    }

    // ---------- Groq ----------

    private fun askGroq(jpeg: ByteArray): String {
        val key = prefs.getString("key", "") ?: ""
        if (key.isEmpty()) return "No API key saved"
        val b64 = Base64.encodeToString(jpeg, Base64.NO_WRAP)

        val prompt = "Реши задачу на фото. Ответь только итоговым ответом, без пояснений и без решения. Например: 14. Не больше 5 слов."

        val content = JSONArray()
            .put(JSONObject().put("type", "text").put("text", prompt))
            .put(JSONObject()
                .put("type", "image_url")
                .put("image_url", JSONObject().put("url", "data:image/jpeg;base64,$b64")))

        val body = JSONObject()
            .put("model", MODEL)
            .put("max_tokens", 800)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", content)))
            .toString()

        val conn = URL("https://api.groq.com/openai/v1/chat/completions").openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.setRequestProperty("Authorization", "Bearer $key")
        conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
        conn.doOutput = true
        conn.connectTimeout = 20000
        conn.readTimeout = 90000
        conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }

        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream.bufferedReader(Charsets.UTF_8).readText()
        if (code !in 200..299) return "HTTP $code: ${text.take(200)}"

        return JSONObject(text).getJSONArray("choices").getJSONObject(0)
            .getJSONObject("message").optString("content", "no content")
    }
}
